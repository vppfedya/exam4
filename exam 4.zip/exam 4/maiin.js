1;
// let son = 5;
// let bolinish = 2;
// let qoldiq = son % bolinish;
// alert("5 sonini 2 ga bo'linganda qoldiq: " + qoldiq);

2;
// let Son = Math.floor(Math.random() * 10) + 1;
// alert("1 dan 10 gacha tasodifiy son: " + randomSon);

3;
// let son = 12.510;
// let butunSon = Math.floor(son);
// console.log(butunSon);

4;
// let sentence = "MARS IT SCHOOL";
// let length = sentence.length;
// console.log("So'z uzunligi: " + length);

5
// function raqamchiqarish() {
//   for (let i = 0; i < 10; i++) {
//     console.log("MARS IT SCHOOL");
//   }
// }
// raqamchiqarish();

6
// let harflar = ["b", "a", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "x", "y", "z"];

// console.log(harflar[4], harflar[7], harflar[16], harflar[2], harflar[1], harflar[20],harflar[17]);
// Yoshni foydalanuvchidan so'rab olamiz

7   
// let yosh = prompt("Iltimos, yoshingizni kiriting:");

// yosh = (yosh);

// if (yosh > 18) {
//     console.log("Siz balag'ot yoshiga yetgansiz");
// }
// else if (yosh === 18) {
//     console.log("Balog'at yoshi muborak!");
// }
// else {
//     console.log("Siz balog'at yoshiga etmagansiz");
// }

8
// let ism = prompt("Ismingizni kiriting:");

// let harflar = [];

// for (var i = 0; i < ism.length; i++) {
//     harflar.push(ism[i]);
// }

// harflar.reverse();

// let teskarism = harflar;

// console.log("Ismingizning teskari:", teskarism);


9
// let raqam = (prompt("1 dan 7 gacha bo'lgan raqam kiriting:"));

// switch (raqam) {
//     case 1:
//         console.log("Siz kiritgan raqam haftaning Dushanba kuniga to'g'ri keladi");
//         break;
//     case 2:
//         console.log("Siz kiritgan raqam haftaning Seshanba kuniga to'g'ri keladi");
//         break;
//     case 3:
//         console.log("Siz kiritgan raqam haftaning Chorshanba kuniga to'g'ri keladi");
//         break;
//     case 4:
//         console.log("Siz kiritgan raqam haftaning Payshanba kuniga to'g'ri keladi");
//         break;
//     case 5:
//         console.log("Siz kiritgan raqam haftaning Juma kuniga to'g'ri keladi");
//         break;
//     case 6:
//         console.log("Siz kiritgan raqam haftaning Shanba kuniga to'g'ri keladi");
//         break;
//     case 7:
//         console.log("Siz kiritgan raqam haftaning Yakshanba kuniga to'g'ri keladi");
//         break;
//     default:
//         console.log("Namalum raqam kiritdingiz");
//         break;
// }
10
// let sonlar = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];

// function Chetnie(arr) {
//     for (let i = 0; i < arr.length; i++) {
//         if (arr[i] % 2 === 0) {
//             console.log(arr[i]);
//         }
//     }
// }

// Chetnie(sonlar);
